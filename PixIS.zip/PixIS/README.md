# PixIS — Phase 1 (Foundation & Visual Identity)

Offline Android keyboard (InputMethodService, Kotlin, no third-party libraries, no permissions).

## Structure
app/src/main/java/com/pixis/keyboard/
- ime/     PixisImeService (the IME), KeyActionListener (view -> IME contract)
- layout/  Key model + KeyboardLayouts (add languages/pages here later)
- view/    KeyboardView (drawing + touch), DotFont (dot-matrix lettering), Palette (Retro Pixel colours)
- setup/   SetupActivity (launcher screen: enable / choose keyboard, test field)
res/: pixel "IS" logo (adaptive icon + in-app logo), IME metadata (xml/method.xml)

## Phase 1 includes
English letters, Shift (tap / double-tap = caps lock), Backspace (hold repeats), Space, Enter (IME action aware),
punctuation + two symbol pages, long-press hints/accents, keyboard-switch (globe) key, auto-capitalisation,
password-field handling (key preview hidden).

## Not in Phase 1 (by design)
Banglish transliteration, Bengali suggestions, autocorrect, clipboard manager, sound settings,
Dark Graphite theme, animations, emoji, swipe typing.

## Privacy
No INTERNET permission, no analytics, no logging, typed text is never stored.
