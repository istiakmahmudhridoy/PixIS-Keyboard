package com.pixis.keyboard.setup

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.pixis.keyboard.R
import com.pixis.keyboard.view.KeyboardView

/** Launcher screen: shows the PixIS identity and walks the user through enabling the keyboard. */
class SetupActivity : Activity() {

    private lateinit var status: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        val logo = ImageView(this).apply { setImageResource(R.drawable.pixis_logo) }
        root.addView(logo, LinearLayout.LayoutParams(dp(96), dp(96)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        addText(root, "PixIS", 28f, true, Color.parseColor("#D6262B"), 8, Gravity.CENTER_HORIZONTAL)
        addText(root, "Retro Pixel keyboard \u2022 offline \u2022 private", 14f, false, Color.parseColor("#5B6270"), 2, Gravity.CENTER_HORIZONTAL)

        status = addText(root, "", 15f, true, Color.parseColor("#264E8C"), 22, Gravity.START)

        addButton(root, "1.  Enable PixIS keyboard") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        addButton(root, "2.  Choose PixIS as your keyboard") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        addText(root, "Try it", 17f, true, Color.parseColor("#1A1C20"), 24, Gravity.START)
        root.addView(EditText(this).apply { hint = "Tap here and type to test" })

        addText(root, "Preview", 17f, true, Color.parseColor("#1A1C20"), 24, Gravity.START)
        val preview = KeyboardView(this).apply { previewOnly = true }
        root.addView(
            preview,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
            }
        )

        addText(
            root,
            "Privacy: PixIS has no internet permission and no other permissions. " +
                "What you type is never saved, logged or sent anywhere.",
            13f, false, Color.parseColor("#5B6270"), 18, Gravity.START
        )
    }

    override fun onResume() {
        super.onResume()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val active = cur.startsWith("$packageName/")
        status.text = when {
            active -> "\u2713 PixIS is your active keyboard"
            enabled -> "Enabled. Now do step 2 to switch to it."
            else -> "Not enabled yet. Start with step 1."
        }
    }

    private fun addText(root: LinearLayout, s: String, sp: Float, bold: Boolean, color: Int, topDp: Int, align: Int): TextView {
        val tv = TextView(this).apply {
            text = s
            textSize = sp
            setTextColor(color)
            gravity = align
            if (bold) setTypeface(null, Typeface.BOLD)
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(topDp)
        root.addView(tv, lp)
        return tv
    }

    private fun addButton(root: LinearLayout, label: String, onClick: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        root.addView(b, lp)
    }
}
