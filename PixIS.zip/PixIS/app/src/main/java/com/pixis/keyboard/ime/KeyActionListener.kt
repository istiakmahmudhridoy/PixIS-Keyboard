package com.pixis.keyboard.ime

/** What the keyboard view asks the input method to do. Later phases add methods here. */
interface KeyActionListener {
    fun onText(text: String)
    fun onBackspace()
    fun onEnter()
    fun onSwitchKeyboard(showPicker: Boolean)
}
