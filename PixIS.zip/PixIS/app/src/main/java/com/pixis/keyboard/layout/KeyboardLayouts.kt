package com.pixis.keyboard.layout

/** All key layouts live here, so later phases can add languages/pages without touching the view. */
object KeyboardLayouts {

    fun caseOf(s: String): String = if (s == "\u00DF") s else s.uppercase()

    private val accents: Map<String, List<String>> = mapOf(
        "a" to listOf("\u00E0", "\u00E1", "\u00E2", "\u00E4", "\u00E6", "\u00E3", "\u00E5", "\u0101"),
        "c" to listOf("\u00E7", "\u0107", "\u010D"),
        "e" to listOf("\u00E8", "\u00E9", "\u00EA", "\u00EB", "\u0113", "\u0117", "\u0119"),
        "i" to listOf("\u00EC", "\u00ED", "\u00EE", "\u00EF", "\u012B", "\u012F"),
        "n" to listOf("\u00F1", "\u0144"),
        "o" to listOf("\u00F2", "\u00F3", "\u00F4", "\u00F6", "\u0153", "\u00F8", "\u014D", "\u00F5"),
        "s" to listOf("\u015B", "\u0161", "\u00DF"),
        "u" to listOf("\u00F9", "\u00FA", "\u00FB", "\u00FC", "\u016B"),
        "y" to listOf("\u00FD", "\u00FF"),
        "z" to listOf("\u017E", "\u017A", "\u017C")
    )

    private val hints: Map<String, String> = mapOf(
        "q" to "1", "w" to "2", "e" to "3", "r" to "4", "t" to "5",
        "y" to "6", "u" to "7", "i" to "8", "o" to "9", "p" to "0",
        "a" to "@", "s" to "#", "d" to "&", "f" to "*", "g" to "-",
        "h" to "!", "j" to "?", "k" to "(", "l" to ")",
        "z" to "\"", "x" to ";", "c" to "\u00E7", "v" to "+", "b" to "'",
        "n" to ":", "m" to "/"
    )

    fun build(page: Page): List<List<Key>> = when (page) {
        Page.LETTERS -> letters()
        Page.SYMBOLS_1 -> symbols1()
        Page.SYMBOLS_2 -> symbols2()
    }

    private fun letterKey(s: String): Key {
        val hint = hints[s]
        val extra = accents[s].orEmpty().filter { it != hint }
        val alts = if (hint != null) listOf(hint) + extra else extra
        return Key(KeyType.CHAR, s, alts = alts, hint = hint)
    }

    private fun letters(): List<List<Key>> {
        val r1 = "qwertyuiop".map { letterKey(it.toString()) }
        val r2 = listOf(Key(KeyType.SPACER, weight = 0.5f)) +
            "asdfghjkl".map { letterKey(it.toString()) } +
            listOf(Key(KeyType.SPACER, weight = 0.5f))
        val r3 = listOf(Key(KeyType.SHIFT, weight = 1.5f)) +
            "zxcvbnm".map { letterKey(it.toString()) } +
            listOf(Key(KeyType.BACKSPACE, weight = 1.5f))
        return listOf(r1, r2, r3, bottom(Key(KeyType.SYMBOLS, "?123", weight = 1.4f)))
    }

    private fun bottom(first: Key): List<Key> = listOf(
        first,
        Key(
            KeyType.CHAR, ",", weight = 1.0f, punct = true, hint = "!",
            alts = listOf("!", ";", ":", "'", "\"", "-", "(", ")")
        ),
        Key(KeyType.SPACE, weight = 5.0f),
        Key(
            KeyType.CHAR, ".", weight = 1.0f, punct = true, hint = ",",
            alts = listOf(",", "?", "!", "\u2026", "@", "/", "_")
        ),
        Key(KeyType.ENTER, weight = 1.6f)
    )

    private fun plain(chars: List<String>): List<Key> = chars.map { Key(KeyType.CHAR, it) }

    private fun symbols1(): List<List<Key>> {
        val r1 = plain(listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"))
        val r2 = plain(listOf("@", "#", "\$", "%", "&", "-", "+", "(", ")", "/"))
        val r3 = listOf(Key(KeyType.SYMBOLS_TOGGLE, "=\\<", weight = 1.5f)) +
            plain(listOf("*", "\"", "'", ":", ";", "!", "?")) +
            listOf(Key(KeyType.BACKSPACE, weight = 1.5f))
        return listOf(r1, r2, r3, bottom(Key(KeyType.LETTERS, "ABC", weight = 1.4f)))
    }

    private fun symbols2(): List<List<Key>> {
        val r1 = plain(listOf("~", "`", "|", "^", "{", "}", "[", "]", "\\", "_"))
        val r2 = listOf(Key(KeyType.SPACER, weight = 3.5f)) +
            plain(listOf("<", ">", "=")) +
            listOf(Key(KeyType.SPACER, weight = 3.5f))
        val r3 = listOf(Key(KeyType.SYMBOLS_TOGGLE, "?123", weight = 1.5f)) +
            listOf(Key(KeyType.SPACER, weight = 7f)) +
            listOf(Key(KeyType.BACKSPACE, weight = 1.5f))
        return listOf(r1, r2, r3, bottom(Key(KeyType.LETTERS, "ABC", weight = 1.4f)))
    }
}
