package com.pixis.keyboard.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.SparseArray
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import com.pixis.keyboard.ime.KeyActionListener
import com.pixis.keyboard.layout.Key
import com.pixis.keyboard.layout.KeyType
import com.pixis.keyboard.layout.KeyboardLayouts
import com.pixis.keyboard.layout.Page
import kotlin.math.max
import kotlin.math.min

/**
 * The Retro Pixel keyboard. Static keys are painted once into a bitmap, so a key press
 * only redraws the pressed key (smooth even on slow phones).
 */
class KeyboardView(context: Context) : View(context) {

    var listener: KeyActionListener? = null

    /** True when used as a non-typing preview (setup screen). */
    var previewOnly: Boolean = false

    private class KeyRect(
        val key: Key,
        val l: Float, val t: Float, val r: Float, val b: Float,
        val color: Int
    )

    private inner class Pointer(val id: Int, var kr: KeyRect) {
        var alts: List<String>? = null
        var idx = 0
        var pLeft = 0f
        var cell = 0f
        var consumed = false
        var repeating = false
        var repeatCount = 0
        val longPress = Runnable { onLongPress(this) }
        val repeat: Runnable = object : Runnable {
            override fun run() {
                onRepeatTick(this@Pointer, this)
            }
        }
    }

    private companion object {
        const val LONG_PRESS_MS = 320L
    }

    private val uiHandler = Handler(Looper.getMainLooper())

    private var pitch = 0f
    private var stripH = 0f
    private var page = Page.LETTERS
    private var shift = 0 // 0 off, 1 once, 2 caps lock
    private var lastShiftTap = 0L
    private var enterLabel: String? = null
    private var sensitive = false

    private val rows = ArrayList<List<Key>>()
    private val rects = ArrayList<KeyRect>()
    private var globe: KeyRect? = null
    private val pointers = SparseArray<Pointer>()

    private var staticBmp: Bitmap? = null
    private var staticCanvas: Canvas? = null
    private var staticDirty = true

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.RIGHT }
    private val tmp = RectF()
    private val fm = Paint.FontMetrics()
    private val letterColors = HashMap<Char, Int>()

    init {
        val y = Palette.YELLOW
        val b = Palette.BLUE
        val d = Palette.DARK
        val c = Palette.CREAM
        val r = Palette.RED
        val order = "qwertyuiopasdfghjklzxcvbnm"
        val cols = intArrayOf(
            y, b, d, c, r, b, c, r, y, d,
            c, r, b, d, y, c, r, b, d,
            d, y, c, r, b, d, y
        )
        for (i in order.indices) letterColors[order[i]] = cols[i]
        linePaint.strokeWidth = dp(1.8f)
        stripH = dp(42f)
        rebuild()
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density

    // ------------------------------------------------------------------ public API

    fun showLetters() = setPage(Page.LETTERS)

    fun showSymbols() = setPage(Page.SYMBOLS_1)

    fun setEnterLabel(s: String?) {
        if (s != enterLabel) {
            enterLabel = s
            staticDirty = true
            invalidate()
        }
    }

    fun setAutoShift(on: Boolean) {
        if (shift == 2) return
        val ns = if (on) 1 else 0
        if (ns != shift) {
            shift = ns
            invalidate()
        }
    }

    /** In password / sensitive fields the large key preview is hidden. */
    fun setSensitive(value: Boolean) {
        sensitive = value
    }

    // ------------------------------------------------------------------ layout

    private fun setPage(p: Page) {
        page = p
        rebuild()
        invalidate()
    }

    private fun rebuild() {
        rows.clear()
        rows.addAll(KeyboardLayouts.build(page))
        layoutKeys()
    }

    private fun updatePitch(widthPx: Int) {
        val dm = resources.displayMetrics
        val wDp = widthPx / dm.density
        var p = (wDp / 8f).coerceIn(40f, 50f) * dm.density
        val avail = (dm.heightPixels * 0.5f - dp(42f) - dp(8f)) / 4f
        if (p > avail) p = max(avail, dp(34f))
        pitch = p
    }

    private fun keyColor(k: Key, ri: Int, ci: Int): Int {
        when (k.type) {
            KeyType.SHIFT, KeyType.SYMBOLS_TOGGLE -> return Palette.YELLOW
            KeyType.BACKSPACE -> return Palette.CREAM
            KeyType.SYMBOLS, KeyType.LETTERS, KeyType.ENTER -> return Palette.RED
            KeyType.SPACE -> return Palette.DARK
            else -> {}
        }
        if (page == Page.LETTERS && k.label.length == 1) {
            val v = letterColors[k.label[0]]
            if (v != null) return v
        }
        if (k.punct) return if (k.label == ",") Palette.CREAM else Palette.DARK
        val pattern = intArrayOf(
            Palette.YELLOW, Palette.BLUE, Palette.DARK, Palette.CREAM, Palette.RED,
            Palette.BLUE, Palette.CREAM, Palette.RED, Palette.YELLOW, Palette.DARK
        )
        return pattern[(ci + ri * 3) % pattern.size]
    }

    private fun layoutKeys() {
        rects.clear()
        staticDirty = true
        val w = width.toFloat()
        if (w <= 0f || rows.isEmpty()) return
        updatePitch(width)
        val side = dp(3f)
        val usable = w - 2 * side
        var top = stripH
        for ((ri, row) in rows.withIndex()) {
            val total = row.fold(0f) { a, k -> a + k.weight }
            var left = side
            for ((ci, k) in row.withIndex()) {
                val kw = usable * k.weight / total
                if (k.type != KeyType.SPACER) {
                    rects.add(KeyRect(k, left, top, left + kw, top + pitch, keyColor(k, ri, ci)))
                }
                left += kw
            }
            top += pitch
        }
        globe = KeyRect(Key(KeyType.SWITCH_KEYBOARD), w - dp(48f), 0f, w, stripH, 0)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        updatePitch(w)
        val h = (stripH + pitch * 4 + dp(8f)).toInt()
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        cancelAll()
    }

    // ------------------------------------------------------------------ drawing

    private fun ensureStatic() {
        val w = width
        val h = height - stripH.toInt()
        if (w <= 0 || h <= 0) return
        var bmp = staticBmp
        if (bmp == null || bmp.width != w || bmp.height != h) {
            bmp?.recycle()
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            staticBmp = bmp
            staticCanvas = Canvas(bmp)
            staticDirty = true
        }
        if (staticDirty) {
            val c = staticCanvas ?: return
            c.drawColor(0, PorterDuff.Mode.CLEAR)
            c.save()
            c.translate(0f, -stripH)
            for (kr in rects) {
                if (kr.key.type != KeyType.SHIFT) drawKeyBody(c, kr, false)
            }
            c.restore()
            staticDirty = false
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Palette.BG)
        drawStrip(canvas)
        ensureStatic()
        val bmp = staticBmp
        if (bmp != null) canvas.drawBitmap(bmp, 0f, stripH, null)

        for (kr in rects) {
            if (kr.key.type == KeyType.SHIFT) drawKeyBody(canvas, kr, isDown(kr))
        }
        for (i in 0 until pointers.size()) {
            val p = pointers.valueAt(i)
            if (p.kr !== globe && p.kr.key.type != KeyType.SHIFT) drawKeyBody(canvas, p.kr, true)
        }
        for (i in 0 until pointers.size()) {
            val p = pointers.valueAt(i)
            val alts = p.alts
            if (alts != null) {
                drawAlts(canvas, p, alts)
            } else if (!previewOnly && !sensitive && p.kr !== globe && p.kr.key.type == KeyType.CHAR) {
                drawPreview(canvas, p.kr)
            }
        }
    }

    private fun isDown(kr: KeyRect): Boolean {
        for (i in 0 until pointers.size()) {
            if (pointers.valueAt(i).kr === kr) return true
        }
        return false
    }

    private fun drawCentered(canvas: Canvas, text: String, cx: Float, cy: Float, size: Float, color: Int) {
        textPaint.textSize = size
        textPaint.color = color
        textPaint.getFontMetrics(fm)
        canvas.drawText(text, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint)
    }

    private fun pressedColor(c: Int): Int =
        if (c == Palette.YELLOW || c == Palette.CREAM) Palette.blend(c, Color.BLACK, 0.18f)
        else Palette.blend(c, Color.WHITE, 0.2f)

    private fun drawLabel(c: Canvas, text: String, cx: Float, cy: Float, dotPitch: Float, dotR: Float, on: Int, bodyH: Float) {
        if (DotFont.canDraw(text)) {
            dotPaint.color = on
            val p = if (text.length >= 3) dotPitch * 0.82f else dotPitch
            DotFont.drawText(c, text, cx, cy, p, dotR * (p / dotPitch), dotPaint)
        } else {
            val size = if (text.length > 2) bodyH * 0.30f else bodyH * 0.45f
            drawCentered(c, text, cx, cy, size, on)
        }
    }

    private fun drawKeyBody(c: Canvas, kr: KeyRect, pressed: Boolean) {
        val k = kr.key
        val gx = dp(1.5f)
        val gy = dp(3.5f)
        val radius = dp(8f)
        tmp.set(kr.l + gx, kr.t + gy, kr.r - gx, kr.b - gy)
        fillPaint.color = if (pressed) pressedColor(kr.color) else kr.color
        c.drawRoundRect(tmp, radius, radius, fillPaint)

        val on = Palette.dotOn(kr.color)
        val bodyH = tmp.height()
        val cx = (kr.l + kr.r) / 2f
        val cy = (kr.t + kr.b) / 2f
        val dotPitch = bodyH * 0.0725f
        val dotR = dotPitch * 0.34f
        dotPaint.color = on

        when (k.type) {
            KeyType.CHAR -> {
                drawLabel(c, k.label.uppercase(), cx, cy, dotPitch, dotR, on, bodyH)
                val hint = k.hint
                if (hint != null) {
                    hintPaint.textSize = bodyH * 0.24f
                    hintPaint.color = (on and 0x00FFFFFF) or (150 shl 24)
                    c.drawText(hint, tmp.right - dp(4f), tmp.top + bodyH * 0.24f + dp(2f), hintPaint)
                }
            }
            KeyType.SHIFT -> {
                val grid = when (shift) {
                    0 -> DotFont.SHIFT_OFF
                    1 -> DotFont.SHIFT_ON
                    else -> DotFont.SHIFT_LOCK
                }
                DotFont.drawGrid(c, grid, cx, cy, dotPitch * 1.05f, dotR * 1.05f, dotPaint)
            }
            KeyType.BACKSPACE -> DotFont.drawGrid(c, DotFont.BACKSPACE, cx, cy, dotPitch * 0.95f, dotR * 0.95f, dotPaint)
            KeyType.ENTER -> {
                val label = enterLabel
                if (label != null) drawLabel(c, label.uppercase(), cx, cy, dotPitch, dotR, on, bodyH)
                else DotFont.drawGrid(c, DotFont.ENTER, cx, cy, dotPitch * 1.05f, dotR * 1.05f, dotPaint)
            }
            KeyType.SPACE -> {}
            else -> drawLabel(c, k.label, cx, cy, dotPitch, dotR, on, bodyH)
        }
    }

    private fun drawStrip(canvas: Canvas) {
        val w = width.toFloat()
        val cy = stripH / 2f
        val gx = w - dp(22f)
        fillPaint.color = if (globe != null && isDown(globe!!)) Palette.DARK else Palette.CIRCLE
        canvas.drawCircle(gx, cy, dp(16f), fillPaint)
        val gr = dp(8.5f)
        linePaint.style = Paint.Style.STROKE
        canvas.drawCircle(gx, cy, gr, linePaint)
        canvas.drawLine(gx - gr, cy, gx + gr, cy, linePaint)
        tmp.set(gx - gr * 0.45f, cy - gr, gx + gr * 0.45f, cy + gr)
        canvas.drawOval(tmp, linePaint)
    }

    private fun drawPreview(canvas: Canvas, kr: KeyRect) {
        val k = kr.key
        val bodyH = pitch - dp(7f)
        val w = max((kr.r - kr.l) * 1.3f, dp(50f))
        val cx = (kr.l + kr.r) / 2f
        val left = (cx - w / 2f).coerceIn(0f, max(0f, width - w))
        val bottom = kr.t + dp(8f)
        val h = min(bodyH * 1.3f, bottom - dp(2f))
        val top = bottom - h
        tmp.set(left, top, left + w, bottom)
        shadowPaint.color = Color.argb(90, 0, 0, 0)
        canvas.drawRoundRect(tmp.left, tmp.top + dp(2f), tmp.right, tmp.bottom + dp(2f), dp(12f), dp(12f), shadowPaint)
        fillPaint.color = kr.color
        canvas.drawRoundRect(tmp, dp(12f), dp(12f), fillPaint)
        val on = Palette.dotOn(kr.color)
        val label = k.label.uppercase()
        val cxp = left + w / 2f
        val cyp = (top + bottom) / 2f - dp(2f)
        val pp = h * 0.0925f
        if (DotFont.canDraw(label)) {
            dotPaint.color = on
            DotFont.drawText(canvas, label, cxp, cyp, pp, pp * 0.34f, dotPaint)
        } else {
            drawCentered(canvas, label, cxp, cyp, h * 0.5f, on)
        }
    }

    private fun drawAlts(canvas: Canvas, p: Pointer, alts: List<String>) {
        val kr = p.kr
        val bodyH = pitch - dp(7f)
        val bottom = kr.t + dp(8f)
        val h = min(bodyH * 1.3f, bottom - dp(2f))
        val top = bottom - h
        val total = p.cell * alts.size
        tmp.set(p.pLeft, top, p.pLeft + total, bottom)
        shadowPaint.color = Color.argb(90, 0, 0, 0)
        canvas.drawRoundRect(tmp.left, tmp.top + dp(2f), tmp.right, tmp.bottom + dp(2f), dp(12f), dp(12f), shadowPaint)
        fillPaint.color = Palette.DARK
        canvas.drawRoundRect(tmp, dp(12f), dp(12f), fillPaint)
        for (i in alts.indices) {
            val cl = p.pLeft + i * p.cell
            val selected = i == p.idx
            if (selected) {
                tmp.set(cl + dp(3f), top + dp(4f), cl + p.cell - dp(3f), bottom - dp(4f))
                fillPaint.color = Palette.YELLOW
                canvas.drawRoundRect(tmp, dp(9f), dp(9f), fillPaint)
            }
            val a = alts[i]
            val col = if (selected) Color.parseColor("#15161A") else Color.WHITE
            val size = if (a.length > 2) h * 0.34f else h * 0.46f
            drawCentered(canvas, a, cl + p.cell / 2f, (top + bottom) / 2f, size, col)
        }
    }

    // ------------------------------------------------------------------ touch

    private fun hitTest(x: Float, y: Float): KeyRect? {
        if (y < stripH) {
            val g = globe
            return if (g != null && x >= g.l && x < g.r) g else null
        }
        val yy = y.coerceIn(stripH, stripH + pitch * rows.size - 0.5f)
        var best: KeyRect? = null
        var bestD = Float.MAX_VALUE
        for (kr in rects) {
            if (yy < kr.t || yy >= kr.b) continue
            val d = if (x < kr.l) kr.l - x else if (x >= kr.r) x - kr.r else 0f
            if (d < bestD) {
                bestD = d
                best = kr
            }
        }
        return best
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                pointerDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    pointerMove(e.getPointerId(i), e.getX(i), e.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                pointerUp(e.getPointerId(e.actionIndex))
            }
            MotionEvent.ACTION_CANCEL -> cancelAll()
        }
        return true
    }

    private fun pointerDown(id: Int, x: Float, y: Float) {
        val kr = hitTest(x, y) ?: return
        val old = pointers.get(id)
        if (old != null) cancelCallbacks(old)
        val p = Pointer(id, kr)
        pointers.put(id, p)
        if (!previewOnly) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            uiHandler.postDelayed(p.longPress, LONG_PRESS_MS)
        }
        invalidate()
    }

    private fun pointerMove(id: Int, x: Float, y: Float) {
        val p = pointers.get(id) ?: return
        if (previewOnly) return
        val alts = p.alts
        if (alts != null) {
            val ni = ((x - p.pLeft) / p.cell).toInt().coerceIn(0, alts.size - 1)
            if (ni != p.idx) {
                p.idx = ni
                invalidate()
            }
            return
        }
        if (p.repeating || p.consumed || p.kr === globe) return
        val kr = hitTest(x, y) ?: return
        if (kr !== p.kr && kr !== globe) {
            uiHandler.removeCallbacks(p.longPress)
            p.kr = kr
            uiHandler.postDelayed(p.longPress, LONG_PRESS_MS)
            invalidate()
        }
    }

    private fun pointerUp(id: Int) {
        val p = pointers.get(id) ?: return
        pointers.remove(id)
        cancelCallbacks(p)
        if (!previewOnly) {
            val alts = p.alts
            if (alts != null) {
                emit(alts[p.idx.coerceIn(0, alts.size - 1)])
            } else if (!p.consumed) {
                onKeyTap(p.kr.key)
            }
        }
        invalidate()
    }

    private fun cancelCallbacks(p: Pointer) {
        p.repeating = false
        uiHandler.removeCallbacks(p.longPress)
        uiHandler.removeCallbacks(p.repeat)
    }

    private fun cancelAll() {
        for (i in 0 until pointers.size()) cancelCallbacks(pointers.valueAt(i))
        pointers.clear()
        invalidate()
    }

    private fun onLongPress(p: Pointer) {
        if (previewOnly || pointers.get(p.id) !== p) return
        val k = p.kr.key
        when (k.type) {
            KeyType.BACKSPACE -> {
                p.consumed = true
                p.repeating = true
                listener?.onBackspace()
                uiHandler.postDelayed(p.repeat, 90L)
            }
            KeyType.SWITCH_KEYBOARD -> {
                p.consumed = true
                listener?.onSwitchKeyboard(true)
            }
            KeyType.CHAR -> {
                if (k.alts.isNotEmpty()) showAlts(p)
            }
            else -> {}
        }
    }

    private fun onRepeatTick(p: Pointer, r: Runnable) {
        if (!p.repeating) return
        p.repeatCount++
        listener?.onBackspace()
        uiHandler.postDelayed(r, if (p.repeatCount < 8) 70L else 42L)
    }

    private fun showAlts(p: Pointer) {
        val k = p.kr.key
        var list = k.alts.map { if (page == Page.LETTERS && shift != 0) KeyboardLayouts.caseOf(it) else it }
        val n = list.size
        val cx = (p.kr.l + p.kr.r) / 2f
        val rightSide = cx >= width / 2f
        if (rightSide) list = list.reversed()
        val cell = max(dp(42f), p.kr.r - p.kr.l)
        val total = cell * n
        val rawLeft = if (rightSide) p.kr.r - total else p.kr.l
        val left = rawLeft.coerceIn(0f, max(0f, width - total))
        p.alts = list
        p.cell = cell
        p.pLeft = left
        p.idx = ((cx - left) / cell).toInt().coerceIn(0, n - 1)
        p.consumed = true
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        invalidate()
    }

    // ------------------------------------------------------------------ actions

    private fun emit(t: String) {
        if (page == Page.LETTERS && shift == 1) shift = 0
        listener?.onText(t)
        invalidate()
    }

    private fun onKeyTap(k: Key) {
        when (k.type) {
            KeyType.CHAR -> {
                val t = if (page == Page.LETTERS && shift != 0) KeyboardLayouts.caseOf(k.output) else k.output
                emit(t)
            }
            KeyType.SHIFT -> {
                val now = SystemClock.uptimeMillis()
                shift = when (shift) {
                    0 -> 1
                    1 -> if (now - lastShiftTap < 350L) 2 else 0
                    else -> 0
                }
                lastShiftTap = now
                invalidate()
            }
            KeyType.BACKSPACE -> listener?.onBackspace()
            KeyType.SPACE -> emit(" ")
            KeyType.ENTER -> listener?.onEnter()
            KeyType.SYMBOLS -> setPage(Page.SYMBOLS_1)
            KeyType.LETTERS -> setPage(Page.LETTERS)
            KeyType.SYMBOLS_TOGGLE -> setPage(if (page == Page.SYMBOLS_1) Page.SYMBOLS_2 else Page.SYMBOLS_1)
            KeyType.SWITCH_KEYBOARD -> listener?.onSwitchKeyboard(false)
            else -> {}
        }
    }
}
