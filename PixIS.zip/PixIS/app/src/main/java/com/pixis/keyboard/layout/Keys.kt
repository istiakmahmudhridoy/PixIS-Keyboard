package com.pixis.keyboard.layout

enum class Page { LETTERS, SYMBOLS_1, SYMBOLS_2 }

enum class KeyType {
    CHAR, SHIFT, BACKSPACE, SPACE, ENTER,
    SYMBOLS, SYMBOLS_TOGGLE, LETTERS, SWITCH_KEYBOARD, SPACER
}

/**
 * One key. [label] is what is drawn, [output] is what is typed, [hint] is the small
 * character in the corner, [alts] are the characters offered on long-press.
 */
class Key(
    val type: KeyType,
    val label: String = "",
    val output: String = label,
    val weight: Float = 1f,
    val alts: List<String> = emptyList(),
    val hint: String? = null,
    val punct: Boolean = false
)
