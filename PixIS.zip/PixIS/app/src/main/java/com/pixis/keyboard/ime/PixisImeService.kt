package com.pixis.keyboard.ime

import android.inputmethodservice.InputMethodService
import android.os.Build
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import com.pixis.keyboard.view.KeyboardView

/**
 * PixIS input method. Phase 1: types characters straight into the focused field.
 * Nothing the user types is stored, logged or sent anywhere.
 */
class PixisImeService : InputMethodService(), KeyActionListener {

    private var kbView: KeyboardView? = null

    override fun onCreateInputView(): View {
        val v = KeyboardView(this)
        v.listener = this
        kbView = v
        return v
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val v = kbView ?: return
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        if (cls == InputType.TYPE_CLASS_NUMBER ||
            cls == InputType.TYPE_CLASS_PHONE ||
            cls == InputType.TYPE_CLASS_DATETIME
        ) {
            v.showSymbols()
        } else {
            v.showLetters()
        }
        v.setSensitive(isPasswordField(info))
        v.setEnterLabel(enterLabelFor(info))
        v.setAutoShift(false)
        updateAutoCaps()
    }

    private fun isPasswordField(info: EditorInfo): Boolean {
        val t = info.inputType
        val cls = t and InputType.TYPE_MASK_CLASS
        val variation = t and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_CLASS_TEXT) {
            return variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
        }
        if (cls == InputType.TYPE_CLASS_NUMBER) {
            return variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        return false
    }

    private fun enterLabelFor(info: EditorInfo): String? {
        val noEnter = (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        val multi = (info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        if (noEnter || multi) return null
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_SEARCH -> "Search"
            EditorInfo.IME_ACTION_SEND -> "Send"
            EditorInfo.IME_ACTION_NEXT -> "Next"
            EditorInfo.IME_ACTION_DONE -> "Done"
            else -> null
        }
    }

    private fun capsAllowed(info: EditorInfo): Boolean {
        if (isPasswordField(info)) return false
        val t = info.inputType
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        val variation = t and InputType.TYPE_MASK_VARIATION
        if (variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI
        ) return false
        val flags = InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or
            InputType.TYPE_TEXT_FLAG_CAP_WORDS or
            InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        return (t and flags) != 0
    }

    private fun updateAutoCaps() {
        val v = kbView ?: return
        val info: EditorInfo = currentInputEditorInfo ?: return
        if (!capsAllowed(info)) {
            v.setAutoShift(false)
            return
        }
        val caps = currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0
        v.setAutoShift(caps != 0)
    }

    // ---------------------------------------------------------------- KeyActionListener

    override fun onText(text: String) {
        currentInputConnection?.commitText(text, 1)
        updateAutoCaps()
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            val before = ic.getTextBeforeCursor(1, 0)
            if (before.isNullOrEmpty()) {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            } else {
                ic.deleteSurroundingTextInCodePoints(1, 0)
            }
        }
        updateAutoCaps()
    }

    override fun onEnter() {
        val info: EditorInfo? = currentInputEditorInfo
        val ic = currentInputConnection
        if (info == null || ic == null) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            return
        }
        val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
        val noEnter = (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        val multi = (info.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        if (!noEnter && !multi &&
            action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateAutoCaps()
    }

    override fun onSwitchKeyboard(showPicker: Boolean) {
        val imm = getSystemService(InputMethodManager::class.java) ?: return
        if (showPicker) {
            imm.showInputMethodPicker()
            return
        }
        val switched: Boolean = if (Build.VERSION.SDK_INT >= 28) {
            switchToNextInputMethod(false)
        } else {
            val token = window?.window?.attributes?.token
            if (token != null) {
                @Suppress("DEPRECATION")
                imm.switchToNextInputMethod(token, false)
            } else {
                false
            }
        }
        if (!switched) imm.showInputMethodPicker()
    }
}
