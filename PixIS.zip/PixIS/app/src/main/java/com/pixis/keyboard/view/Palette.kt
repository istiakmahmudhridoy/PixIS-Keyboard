package com.pixis.keyboard.view

import android.graphics.Color

/** Retro Pixel theme colours (sampled from the reference screenshot). */
object Palette {
    val BG: Int = Color.parseColor("#000000")
    val YELLOW: Int = Color.parseColor("#E4B630")
    val BLUE: Int = Color.parseColor("#264E8C")
    val RED: Int = Color.parseColor("#C43838")
    val CREAM: Int = Color.parseColor("#E8E6E1")
    val DARK: Int = Color.parseColor("#1A1C20")
    val CIRCLE: Int = Color.parseColor("#17191D")
    private val INK: Int = Color.parseColor("#15161A")

    /** Colour of the dots / text drawn on top of a key of this colour. */
    fun dotOn(keyColor: Int): Int = if (keyColor == YELLOW || keyColor == CREAM) INK else Color.WHITE

    fun blend(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.rgb(r, g, bl)
    }
}
